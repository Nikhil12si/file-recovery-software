========================================================================
HDD File Recovery Suite - Windows Recovery Agent (Local Engine)
========================================================================

This package contains the local C++ disk scanning engine and FastAPI service
needed to scan and recover deleted or formatted files on your Windows drives.

REQUIREMENTS:
1. Windows 10 or 11 (64-bit)
2. Python 3.10+ installed from https://www.python.org/downloads/
   (IMPORTANT: Check the box 'Add python.exe to PATH' during installation)
3. Administrator Rights (needed to inspect raw disk sectors and MFT records)

QUICK START:
1. Extract all files from this ZIP to a folder (e.g. C:\RecoveryAgent)
2. Right-click 'start-agent.bat' and select 'Run as Administrator'
3. Wait for the terminal window to display:
   'Uvicorn running on http://127.0.0.1:8000'
4. Open the website (Agent Setup page) and click 'Verify Setup' to connect!

MANUAL TERMINAL START (Alternative):
If you prefer running via PowerShell / Command Prompt:
1. Open PowerShell as Administrator
2. Navigate to this folder:
   cd C:\RecoveryAgent
3. Install required Python packages:
   pip install -r backendequirements.txt
4. Run the recovery service:
   python backendecovery_service.py

SAFETY REMINDER:
Never restore recovered files to the same partition being scanned. Always
select a separate drive or external storage as the destination folder.
========================================================================
